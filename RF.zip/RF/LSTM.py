import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# 데이터 전처리 함수 정의
def preprocess_data(file_path):
    df = pd.read_csv(file_path)
    required_columns = ['Ch 1', 'Ch 2', 'Ch 3', 'Ch 4', 'Ch 5', 'Ch 6']
    if all(col in df.columns for col in required_columns):
        data = df[required_columns].values
        return data
    else:
        print(f"Missing one or more required columns in file {file_path}")
        return None

# 파일 경로 리스트 정의
file_paths = [
   "1_data(total)_dh.csv", "2_data(total)_dh.csv", "3_data(total)_dh.csv",  # 보행 데이터 파일 경로
    "4_data(total)_dh.csv", "5_data(total)_dh.csv",
    "1_data(total)_jae.csv", "2_data(total)_jae.csv", "3_data(total)_jae.csv",
    "4_data(total)_jae.csv", "5_data(total)_jae.csv",
    "1_data(total)_jung.csv", "2_data(total)_jung.csv", "3_data(total)_jung.csv",
    "4_data(total)_jung.csv", "5_data(total)_jung.csv",
    "up1_RMS_total(dh).csv", "up2_RMS_total(dh).csv", "up3_RMS_total(dh).csv",  # 계단 오르기 데이터 파일 경로
    "up4_RMS_total(dh).csv", "up5_RMS_total(dh).csv", "up6_RMS_total(dh).csv",
    "up7_RMS_total(dh).csv", "up8_RMS_total(dh).csv", "up8_RMS_total(dh).csv", "up10_RMS_total(dh).csv",
    "up1_RMS_total(g).csv", "up2_RMS_total(g).csv", "up3_RMS_total(g).csv",
    "up4_RMS_total(g).csv", "up5_RMS_total(g).csv", "up6_RMS_total(g).csv",
    "up7_RMS_total(g).csv", "up8_RMS_total(g).csv", "up8_RMS_total(g).csv", "up10_RMS_total(g).csv",
    "up1_RMS_total(s).csv", "up2_RMS_total(s).csv", "up3_RMS_total(s).csv",
    "up4_RMS_total(s).csv", "up5_RMS_total(s).csv", "up6_RMS_total(s).csv",
    "up7_RMS_total(s).csv", "up8_RMS_total(s).csv", "up8_RMS_total(s).csv", "up10_RMS_total(s).csv",
    "down1_RMS_total(dh).csv", "down2_RMS_total(dh).csv", "down3_RMS_total(dh).csv",  # 계단 내리기 데이터 파일 경로
    "down4_RMS_total(dh).csv", "down5_RMS_total(dh).csv", "down6_RMS_total(dh).csv",
    "down7_RMS_total(dh).csv", "down8_RMS_total(dh).csv", "down9_RMS_total(dh).csv", "down10_RMS_total(dh).csv",
    "down1_RMS_total(g).csv", "down2_RMS_total(g).csv", "down3_RMS_total(g).csv",
    "down4_RMS_total(g).csv", "down5_RMS_total(g).csv", "down6_RMS_total(g).csv",
    "down7_RMS_total(g).csv", "down8_RMS_total(g).csv", "down9_RMS_total(g).csv", "down10_RMS_total(g).csv",
    "down1_RMS_total(s).csv", "down2_RMS_total(s).csv", "down3_RMS_total(s).csv",
    "down4_RMS_total(s).csv", "down5_RMS_total(s).csv", "down6_RMS_total(s).csv",
    "down7_RMS_total(s).csv", "down8_RMS_total(s).csv", "down9_RMS_total(s).csv", "down10_RMS_total(s).csv"
]

base_dir = "C:/Users/KYH/Desktop/deeplearning/LSTM"
# 데이터를 저장할 리스트
X = []
y = []

# 데이터와 레이블 로드
for file_path in file_paths:
    file_name = os.path.basename(file_path)
    label = 1 if 'dh' in file_name else 0  # 1: 보행, 0: 계단 오르기
    features = preprocess_data(os.path.join(base_dir, file_path))
    if features is not None:
        X.append(features)
        y.extend([label] * features.shape[0])

# 리스트를 numpy 배열로 변환
X = np.vstack(X)
y = np.array(y)

# 데이터 정규화
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 시계열 데이터로 변환 (LSTM 입력 형식에 맞게 조정)
timesteps = 30  # 타임스텝 설정 (하나의 샘플이 30개의 시퀀스를 가짐)
X_lstm = []
for i in range(timesteps, X.shape[0]):
    X_lstm.append(X[i-timesteps:i, :])
X_lstm = np.array(X_lstm)
y_lstm = y[timesteps:]

# 데이터 분할: 훈련, 검증, 테스트 데이터 나누기
X_train, X_test, y_train, y_test = train_test_split(X_lstm, y_lstm, test_size=0.3, random_state=42)
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.3, random_state=42)

# LSTM 모델 생성
model = Sequential()
model.add(LSTM(units=64, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])))
model.add(Dropout(0.2))
model.add(LSTM(units=64))
model.add(Dropout(0.2))
model.add(Dense(units=1, activation='sigmoid'))

# 모델 컴파일
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# 모델 학습
history = model.fit(X_train, y_train, epochs=20, batch_size=64, validation_data=(X_val, y_val))

# 테스트 데이터 예측
y_pred = (model.predict(X_test) > 0.5).astype("int32")

# 평가
accuracy = accuracy_score(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)

print("테스트 데이터 정확도:", accuracy)
print("혼동 행렬:\n", conf_matrix)

# 혼동 행렬 시각화
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=['계단 오르기', '보행'], yticklabels=['계단 오르기', '보행'])
plt.xlabel('Predicted labels')
plt.ylabel('Actual labels')
plt.title('Confusion Matrix')
plt.show()

# 학습 성능 시각화
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.title('Training and Validation Accuracy')
plt.legend()
plt.grid(True)
plt.show()
